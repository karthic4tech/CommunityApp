import { ChangeDetectionStrategy, Component, inject, input } from '@angular/core';
import { ServiceCategory } from '../core/models/service-category';
import { LanguageService } from '../core/services/language.service';

const ICONS: Readonly<Record<string, string>> = {
  house: '⌂', heart: '♡', 'hard-hat': '🏗', hospital: '✚', 'graduation-cap': '🎓',
  'book-open': '📖', utensils: '🍽', users: '👥', 'car-front': '🚕', 'flower-2': '✿',
  recycle: '♻', store: '🏪', dumbbell: '🏋', landmark: '🏛', 'calendar-days': '📅',
  'briefcase-business': '💼', 'building-2': '🏢', 'heart-handshake': '🤝', car: '🚗',
  sprout: '🌱', 'monitor-smartphone': '💻', 'paw-print': '🐾',
};

@Component({
  selector: 'app-category-card',
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <details [id]="'category-' + category().slug">
      <summary>
        <span class="icon" aria-hidden="true">{{ iconFor(category().icon) }}</span>
        <span class="labels"><strong [lang]="i18n.language()">{{ i18n.language() === 'ta' ? category().nameTamil : category().nameEnglish }}</strong>
          <span [lang]="i18n.secondaryLanguage()">{{ i18n.language() === 'ta' ? category().nameEnglish : category().nameTamil }}</span>
        </span>
      </summary>
      <div class="body">
        @if (category().description) { <p lang="ta">{{ category().description }}</p> }
        @if (category().subcategories.length) {
          <ul>
            @for (child of category().subcategories; track child.id) {
              <li><app-category-card [category]="child" /></li>
            }
          </ul>
        } @else { <p>{{ i18n.text().noChildren }}</p> }
      </div>
    </details>
  `,
  styles: `
    :host { display: block; }
    details { border: 1px solid #cbd5d1; border-radius: 1rem; background: #fff; overflow-wrap: anywhere; }
    summary { cursor: pointer; padding: 1.1rem; min-height: 3rem; }
    summary::marker { color: #176044; }
    summary:focus-visible { outline: 3px solid #176044; outline-offset: -4px; border-radius: 1rem; }
    .icon { font-size: 1.6rem; margin-inline: .5rem; }
    .labels { display: inline-flex; vertical-align: middle; flex-direction: column; gap: .35rem; max-width: 75%; }
    strong { color: #153e30; line-height: 1.7; }
    .labels > span { color: #47594f; font-size: .85rem; }
    .body { padding: 0 1rem 1rem; }
    p { line-height: 1.8; color: #47594f; }
    ul { list-style: none; padding: 0; display: grid; gap: .65rem; }
  `,
})
export class CategoryCardComponent {
  readonly category = input.required<ServiceCategory>();
  protected readonly i18n = inject(LanguageService);

  protected iconFor(name: string | null): string {
    return ICONS[name ?? ''] ?? '◇';
  }
}
