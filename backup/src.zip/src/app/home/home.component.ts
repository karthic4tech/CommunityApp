import { ChangeDetectionStrategy, Component, OnInit, inject } from '@angular/core';
import { ServiceCategoryService } from '../core/services/service-category.service';
import { CategoryCardComponent } from './category-card.component';
import { LanguageService } from '../core/services/language.service';

@Component({
  selector: 'app-home',
  imports: [CategoryCardComponent],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <header><a href="#main">{{ i18n.text().skip }}</a>
      <div class="header-row">
        <p class="brand">{{ i18n.text().brand }} <span [lang]="i18n.secondaryLanguage()">{{ i18n.text().secondaryBrand }}</span></p>
        <div class="language-switch" role="group" aria-label="Language / மொழி">
          <button type="button" lang="ta" [attr.aria-pressed]="i18n.language() === 'ta'" (click)="i18n.setLanguage('ta')">தமிழ்</button>
          <button type="button" lang="en" [attr.aria-pressed]="i18n.language() === 'en'" (click)="i18n.setLanguage('en')">English</button>
        </div>
      </div>
    </header>
    <main id="main" tabindex="-1">
      <section class="intro" aria-labelledby="home-title">
        <p>{{ i18n.text().tagline }}</p>
        <h1 id="home-title">{{ i18n.text().title }}</h1>
        <p>{{ i18n.text().intro }}</p>
      </section>
      <section aria-labelledby="categories-title" [attr.aria-busy]="service.loading()">
        <h2 id="categories-title">{{ i18n.text().categories }}</h2>
        @if (service.loading()) {
          <p role="status">{{ i18n.text().loading }}</p>
        } @else if (service.error()) {
          <div class="state"><p role="alert">{{ i18n.text().error }}</p>
            <button type="button" (click)="service.refresh()">{{ i18n.text().retry }}</button>
          </div>
        } @else if (!service.categories().length) {
          <div class="state"><p role="status">{{ i18n.text().empty }}</p>
            <button type="button" (click)="service.refresh()">{{ i18n.text().refresh }}</button>
          </div>
        } @else {
          <div class="categories">
            @for (category of service.categories(); track category.id) {
              <app-category-card [category]="category" />
            }
          </div>
        }
      </section>
    </main>
    <footer>{{ i18n.text().footer }}</footer>
  `,
  styles: `
    :host { display: block; }
    header, main, footer { max-width: 72rem; margin-inline: auto; padding: 1.25rem; }
    header > a { color: #17583f; }
    .header-row { display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 1rem; }
    .language-switch { display: flex; gap: .5rem; }
    .language-switch button[aria-pressed='false'] { background: white; color: #17583f; box-shadow: inset 0 0 0 1px #17583f; }
    .brand { font-weight: 700; font-size: 1.3rem; color: #153e30; }
    .brand span { display: block; font-size: .85rem; margin-top: .4rem; }
    .intro { padding-block: 1rem 2rem; max-width: 48rem; line-height: 1.9; }
    h1 { font-size: clamp(1.6rem, 4vw, 2.5rem); line-height: 1.6; }
    h2 { font-size: 1.2rem; margin-bottom: 1.5rem; }
    .categories { display: grid; grid-template-columns: repeat(auto-fit, minmax(min(100%, 21rem), 1fr)); gap: 1rem; align-items: start; }
    .state { padding: 1.5rem; border: 1px solid #cbd5d1; border-radius: 1rem; background: white; line-height: 1.8; }
    button { border: 0; border-radius: .5rem; background: #17583f; color: white; padding: .8rem 1rem; font: inherit; cursor: pointer; min-height: 44px; }
    footer { margin-top: 2rem; color: #47594f; }
  `,
})
export class HomeComponent implements OnInit {
  protected readonly service = inject(ServiceCategoryService);
  protected readonly i18n = inject(LanguageService);

  ngOnInit(): void {
    void this.service.load();
  }
}
