import { TestBed } from '@angular/core/testing';
import { signal } from '@angular/core';
import { vi } from 'vitest';
import { HomeComponent } from './home.component';
import { ServiceCategoryService } from '../core/services/service-category.service';
import { buildCategoryHierarchy } from '../core/models/service-category';
import { row } from '../core/models/category-test-fixtures';
import { LanguageService } from '../core/services/language.service';

describe('HomeComponent', () => {
  const categories = signal(buildCategoryHierarchy([]));
  const loading = signal(false);
  const error = signal<string | null>(null);
  const refresh = vi.fn();
  const load = vi.fn();

  beforeEach(() => {
    categories.set([]);
    loading.set(false);
    error.set(null);
    vi.clearAllMocks();
    TestBed.configureTestingModule({ imports: [HomeComponent], providers: [
      { provide: ServiceCategoryService, useValue: { categories, loading, error, refresh, load } },
    ] });
    TestBed.inject(LanguageService).setLanguage('ta');
  });

  afterEach(() => TestBed.inject(LanguageService).setLanguage('ta'));

  it('switches UI and nested category names without reloading categories', async () => {
    categories.set(buildCategoryHierarchy([
      row('root', { name_ta: 'வீட்டு சேவைகள்', name_en: 'Home Services' }),
      row('child', { parent_id: 'root', name_en: 'Carpenter' }),
    ]));
    const fixture = TestBed.createComponent(HomeComponent);
    await fixture.whenStable();
    const element: HTMLElement = fixture.nativeElement;
    element.querySelector<HTMLButtonElement>('button[lang="en"]')?.click();
    fixture.detectChanges();
    expect(element.querySelector('h1')?.textContent).toBe('Find the services you need');
    expect(element.querySelector('summary strong')?.textContent).toBe('Home Services');
    expect(element.querySelector('li summary strong')?.textContent).toBe('Carpenter');
    expect(document.documentElement.lang).toBe('en');
    expect(element.querySelector('button[lang="en"]')?.getAttribute('aria-pressed')).toBe('true');
    expect(load).toHaveBeenCalledTimes(1);
    error.set('error');
    fixture.detectChanges();
    expect(element.querySelector('[role="alert"]')?.textContent).toContain('Unable to load');
    element.querySelector<HTMLButtonElement>('button[lang="ta"]')?.click();
    fixture.detectChanges();
    expect(element.querySelector('h1')?.textContent).toContain('உங்களுக்குத் தேவையான');
  });

  it('loads database categories and renders Tamil parents and nested children', async () => {
    categories.set(buildCategoryHierarchy([
      row('root', { name_ta: 'வீட்டு சேவைகள்' }),
      row('child', { parent_id: 'root', name_ta: 'தச்சர் சேவை' }),
    ]));
    const fixture = TestBed.createComponent(HomeComponent);
    await fixture.whenStable();
    const element: HTMLElement = fixture.nativeElement;
    expect(load).toHaveBeenCalledTimes(1);
    expect(element.querySelector('summary')?.textContent).toContain('வீட்டு சேவைகள்');
    expect(element.querySelector('li summary')?.textContent).toContain('தச்சர் சேவை');
    expect(element.querySelector('details')?.id).toBe('category-root');
    const summary = element.querySelector('summary');
    summary?.click();
    expect(element.querySelector('details')?.open).toBe(true);
  });

  it('renders empty, loading and friendly error states with retry', async () => {
    const fixture = TestBed.createComponent(HomeComponent);
    await fixture.whenStable();
    const element: HTMLElement = fixture.nativeElement;
    expect(element.textContent).toContain('தற்போது சேவை வகைகள் எதுவும் கிடைக்கவில்லை.');
    loading.set(true);
    fixture.detectChanges();
    expect(element.querySelector('[role="status"]')?.textContent).toContain('ஏற்றப்படுகின்றன');
    loading.set(false);
    error.set('மீண்டும் முயற்சிக்கவும்');
    fixture.detectChanges();
    expect(element.querySelector('[role="alert"]')).not.toBeNull();
    element.querySelector<HTMLButtonElement>('.state button')?.click();
    expect(refresh).toHaveBeenCalledTimes(1);
  });
});
