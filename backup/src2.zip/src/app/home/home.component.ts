import { ChangeDetectionStrategy, ChangeDetectorRef, Component, OnDestroy, OnInit, inject } from '@angular/core';
import { Router, RouterLink, RouterLinkActive, RouterOutlet } from '@angular/router';
import { DOCUMENT, NgOptimizedImage } from '@angular/common';
import { LanguageService } from '../core/services/language.service';
import { ServiceCategoryService } from '../core/services/service-category.service';
import { ServiceDirectoryService } from '../core/services/service-directory.service';
import { ServiceListing } from '../core/models/service-listing';

interface LandingValue {
  readonly id: string;
  readonly icon: string;
  readonly titleEnglish: string;
  readonly titleTamil: string;
  readonly descriptionEnglish: string;
  readonly descriptionTamil: string;
}

interface ServiceHighlight {
  readonly id: string;
  readonly icon: string;
  readonly tone: string;
  readonly titleEnglish: string;
  readonly titleTamil: string;
  readonly descriptionEnglish: string;
  readonly descriptionTamil: string;
}

const LANDING_VALUES: readonly LandingValue[] = [
  {
    id: 'local', icon: 'bi-geo-alt', titleEnglish: 'Made for our town', titleTamil: 'நம் ஊருக்காக',
    descriptionEnglish: 'Useful local information in one place.', descriptionTamil: 'உள்ளூர் தகவல்கள் ஒரே இடத்தில்.',
  },
  {
    id: 'simple', icon: 'bi-stars', titleEnglish: 'Simple to discover', titleTamil: 'எளிதாகக் கண்டறியுங்கள்',
    descriptionEnglish: 'Find the right service without the noise.', descriptionTamil: 'தேவையான சேவையை விரைவாகக் கண்டறியுங்கள்.',
  },
  {
    id: 'bilingual', icon: 'bi-translate', titleEnglish: 'Tamil + English', titleTamil: 'தமிழ் + ஆங்கிலம்',
    descriptionEnglish: 'A community experience for everyone.', descriptionTamil: 'அனைவருக்குமான சமூக அனுபவம்.',
  },
  {
    id: 'together', icon: 'bi-people', titleEnglish: 'Built together', titleTamil: 'ஒன்றாக உருவாக்குவோம்',
    descriptionEnglish: 'Share what you offer with local people.', descriptionTamil: 'உங்கள் சேவையை உள்ளூர் மக்களுடன் பகிருங்கள்.',
  },
] as const;

const SERVICE_HIGHLIGHTS: readonly ServiceHighlight[] = [
  {
    id: 'home', icon: 'bi-house-heart', tone: 'green', titleEnglish: 'Home & everyday life', titleTamil: 'வீடு மற்றும் அன்றாட வாழ்க்கை',
    descriptionEnglish: 'Find trusted help for the things that keep your home moving.', descriptionTamil: 'உங்கள் வீட்டிற்குத் தேவையான உதவிகளை எளிதாகக் கண்டறியுங்கள்.',
  },
  {
    id: 'wellbeing', icon: 'bi-heart-pulse', tone: 'rose', titleEnglish: 'Health & wellbeing', titleTamil: 'ஆரோக்கியம் மற்றும் நலம்',
    descriptionEnglish: 'Explore healthcare, wellness, and support close to home.', descriptionTamil: 'உங்களுக்கு அருகிலுள்ள சுகாதார மற்றும் நல சேவைகளைப் பாருங்கள்.',
  },
  {
    id: 'learning', icon: 'bi-mortarboard', tone: 'gold', titleEnglish: 'Learning & work', titleTamil: 'கல்வி மற்றும் வேலை',
    descriptionEnglish: 'Connect with opportunities, skills, and local expertise.', descriptionTamil: 'வாய்ப்புகள், திறன்கள் மற்றும் உள்ளூர் நிபுணர்களுடன் இணையுங்கள்.',
  },
  {
    id: 'local-life', icon: 'bi-shop', tone: 'blue', titleEnglish: 'Local businesses', titleTamil: 'உள்ளூர் வணிகங்கள்',
    descriptionEnglish: 'Discover the people and businesses that make our town special.', descriptionTamil: 'நம் ஊரை சிறப்பாக்கும் மனிதர்களையும் வணிகங்களையும் கண்டறியுங்கள்.',
  },
] as const;

@Component({
  selector: 'app-home',
  imports: [RouterLink, RouterLinkActive, RouterOutlet, NgOptimizedImage],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <a class="skip-link" href="#main">{{ i18n.text().skip }}</a>
    <header class="site-header">
      <div class="header-inner">
        <a routerLink="/" class="brand">
          <img ngSrc="assets/images/nam-chidambaram-logo.png"
            width="1672" height="941" priority alt="" aria-hidden="true" class="brand-logo" />
          <span class="brand-copy">
            <strong lang="en">Nam Chidambaram</strong>
            <span lang="ta">நம் சிதம்பரம்</span>
            <small lang="en">Our town · Our people · Our services</small>
          </span>
        </a>
        <form class="header-search" action="/service-search" (submit)="search($event, headerSearch.value)">
          <i class="bi bi-search search-icon" aria-hidden="true"></i>
          <input #headerSearch type="search" name="q" maxlength="200" [placeholder]="i18n.language() === 'ta' ? 'சேவைகளைத் தேடுங்கள்...' : 'Search local services...'" [attr.aria-label]="i18n.language() === 'ta' ? 'சேவைகளைத் தேடுங்கள்' : 'Search local services'">
          <button type="submit" class="search-submit" [attr.aria-label]="i18n.language() === 'ta' ? 'தேடுக' : 'Search'"><i class="bi bi-arrow-right" aria-hidden="true"></i></button>
        </form>
        <div class="language-switch" role="group" aria-label="Language / மொழி">
          <button type="button" lang="ta" [class.active]="i18n.language() === 'ta'" [attr.aria-pressed]="i18n.language() === 'ta'" (click)="i18n.setLanguage('ta')">தமிழ்</button>
          <button type="button" lang="en" [class.active]="i18n.language() === 'en'" [attr.aria-pressed]="i18n.language() === 'en'" (click)="i18n.setLanguage('en')">English</button>
        </div>
      </div>
      <nav class="main-nav" [attr.aria-label]="i18n.language() === 'ta' ? 'முதன்மை வழிசெலுத்தல்' : 'Main navigation'">
        <a routerLink="/" routerLinkActive="nav-active" [routerLinkActiveOptions]="{ exact: true }" ariaCurrentWhenActive="page"><i class="bi bi-house-door" aria-hidden="true"></i><span>{{ i18n.language() === 'ta' ? 'முகப்பு' : 'Home' }}</span></a>
        <a routerLink="/services" routerLinkActive="nav-active" ariaCurrentWhenActive="page"><i class="bi bi-grid" aria-hidden="true"></i><span>{{ i18n.language() === 'ta' ? 'சேவைகள்' : 'Explore Services' }}</span></a>
        <a routerLink="/" fragment="about"><i class="bi bi-compass" aria-hidden="true"></i><span>{{ i18n.language() === 'ta' ? 'நம் கதை' : 'Our story' }}</span></a>
        <a routerLink="/" fragment="community"><i class="bi bi-plus-circle" aria-hidden="true"></i><span>{{ i18n.language() === 'ta' ? 'சேவையைப் பகிருங்கள்' : 'For providers' }}</span></a>
        <a routerLink="/account" routerLinkActive="nav-active" ariaCurrentWhenActive="page"><i class="bi bi-person-circle" aria-hidden="true"></i><span>{{ i18n.language() === 'ta' ? 'கணக்கு' : 'Account' }}</span></a>
        <a routerLink="/admin/login" routerLinkActive="nav-active" ariaCurrentWhenActive="page"><i class="bi bi-shield-lock" aria-hidden="true"></i><span>{{ i18n.language() === 'ta' ? 'நிர்வாகம்' : 'Admin' }}</span></a>
      </nav>
    </header>

    <main id="main" tabindex="-1"><router-outlet (activate)="focusContent()" /></main>
    <footer class="site-footer">
      <div class="footer-inner">
        <div class="footer-intro">
          <a routerLink="/" class="footer-brand">{{ i18n.text().brand }} <small [lang]="i18n.secondaryLanguage()">{{ i18n.text().secondaryBrand }}</small></a>
          <p>{{ i18n.language() === 'ta' ? 'நம் ஊரையும், நம் மக்களையும், நம் சேவைகளையும் இணைக்கும் ஒரு சமூகத் தளம்.' : 'A welcoming local directory connecting our town, our people, and the services we share.' }}</p>
        </div>
        <div class="footer-links">
          <strong>{{ i18n.language() === 'ta' ? 'விரைவு இணைப்புகள்' : 'Explore' }}</strong>
          <a routerLink="/services">{{ i18n.language() === 'ta' ? 'அனைத்து சேவைகள்' : 'All services' }}</a>
          <a routerLink="/" fragment="about">{{ i18n.language() === 'ta' ? 'நம் கதை' : 'Our story' }}</a>
          <a routerLink="/account">{{ i18n.language() === 'ta' ? 'கணக்கு' : 'Account' }}</a>
        </div>
        <div class="footer-links">
          <strong>{{ i18n.language() === 'ta' ? 'சேவை வழங்குநர்களுக்கு' : 'For providers' }}</strong>
          <a routerLink="/services/submit">{{ i18n.language() === 'ta' ? 'சேவையைச் சேர்க்கவும்' : 'Add your service' }}</a>
          <a routerLink="/my-submissions">{{ i18n.language() === 'ta' ? 'எனது சமர்ப்பிப்புகள்' : 'My submissions' }}</a>
          <a routerLink="/admin/login">{{ i18n.language() === 'ta' ? 'நிர்வாக உள்நுழைவு' : 'Admin login' }}</a>
        </div>
      </div>
      <div class="footer-bottom"><span>{{ i18n.text().footer }}</span><span>© {{ i18n.language() === 'ta' ? 'நம் சிதம்பரம்' : 'Nam Chidambaram' }}</span></div>
    </footer>
  `,
  styleUrl: './site-layout.component.scss',
})
export class HomeComponent {
  protected readonly i18n = inject(LanguageService);
  private readonly router = inject(Router);
  private readonly document = inject(DOCUMENT);

  protected search(event: Event, term: string): void {
    event.preventDefault();
    void this.router.navigate([term.trim() ? '/service-search' : '/services'], { queryParams: term.trim() ? { q: term.trim() } : {} });
  }

  protected focusContent(): void {
    this.document.getElementById('main')?.focus({ preventScroll: true });
  }
}

@Component({
  selector: 'app-landing',
  imports: [RouterLink],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="nc-home">
      <section class="nc-hero" aria-labelledby="home-title">
        <div class="nc-hero-shade"></div>
        <div class="nc-hero-copy">
          <p class="nc-eyebrow">{{ i18n.language() === 'ta' ? 'நம் ஊர் · நம் மக்கள் · நம் சேவைகள்' : 'WELCOME TO OUR COMMUNITY' }}</p>
          @if (i18n.language() === 'ta') {
            <h1 id="home-title">நம் சிதம்பரம் <em>நம் மக்களுக்காக</em></h1>
          } @else {
            <h1 id="home-title">Nam Chidambaram <em>Our town, connected.</em></h1>
          }
          <p class="nc-hero-description">{{ i18n.language() === 'ta' ? 'உள்ளூர் சேவைகள், வணிகங்கள், நிகழ்வுகள் மற்றும் சமூகத் தகவல்களை ஒரே இடத்தில் கண்டறியுங்கள்.' : 'Discover trusted local services, businesses, events and community updates in Chidambaram.' }}</p>
          <form class="nc-search" action="/service-search" (submit)="search($event, heroSearch.value)">
            <i class="bi bi-search" aria-hidden="true"></i>
            <input #heroSearch type="search" name="q" maxlength="200" [placeholder]="i18n.language() === 'ta' ? 'சேவைகள், வணிகங்கள், நிகழ்வுகளைத் தேடுங்கள்...' : 'Search services, businesses, events...'" [attr.aria-label]="i18n.language() === 'ta' ? 'தேடுக' : 'Search services, businesses and events'">
            <button type="submit">{{ i18n.language() === 'ta' ? 'தேடுக' : 'Search' }}</button>
          </form>
          <div class="nc-popular"><span>{{ i18n.language() === 'ta' ? 'பிரபலமானவை:' : 'Popular:' }}</span>
            <a routerLink="/services">{{ i18n.language() === 'ta' ? 'வீட்டுச் சேவைகள்' : 'Home Services' }}</a>
            <a routerLink="/services">{{ i18n.language() === 'ta' ? 'மருத்துவம்' : 'Healthcare' }}</a>
            <a routerLink="/services">{{ i18n.language() === 'ta' ? 'கல்வி' : 'Education' }}</a>
            <a routerLink="/services">{{ i18n.language() === 'ta' ? 'உணவு' : 'Food' }}</a>
            <a href="#nc-events">{{ i18n.language() === 'ta' ? 'நிகழ்வுகள்' : 'Events' }}</a>
          </div>
        </div>
        <div class="nc-hero-art" aria-hidden="true">
          <div class="nc-hero-art-sun"></div><div class="nc-temple-shape">
            <span class="nc-gopuram-tier tier-1"></span><span class="nc-gopuram-tier tier-2"></span><span class="nc-gopuram-tier tier-3"></span><span class="nc-gopuram-tier tier-4"></span><span class="nc-gopuram-top"></span>
          </div>
          <div class="nc-hero-art-horizon"></div>
          <div class="nc-hero-slide-count"><span>01</span><i></i><span>03</span></div>
        </div>
      </section>

      <section class="nc-section nc-categories" id="categories" aria-labelledby="nc-category-title">
        <div class="nc-section-heading">
          <div><h2 id="nc-category-title">{{ i18n.language() === 'ta' ? 'சேவைகளை கண்டுபிடி' : 'Our Services' }}</h2><p>{{ i18n.language() === 'ta' ? 'தமிழ் மற்றும் ஆங்கிலத்தில் உள்ளூர் நம்பகமான சேவைகளைக் கண்டறியுங்கள்.' : 'Find trusted local services in your language and community.' }}</p></div>
          <a class="nc-view-link" routerLink="/services">{{ i18n.language() === 'ta' ? 'அனைத்தையும் பார்க்க' : 'View all categories' }} <i class="bi bi-arrow-right"></i></a>
        </div>
        @if (categoryService.loading()) {
          <p class="nc-state">{{ i18n.language() === 'ta' ? 'வகைகள் ஏற்றப்படுகின்றன…' : 'Loading categories…' }}</p>
        } @else if (categoryService.error()) {
          <p class="nc-state">{{ i18n.language() === 'ta' ? 'வகைகளை ஏற்ற முடியவில்லை.' : 'Categories could not be loaded.' }} <button type="button" (click)="loadCategories()">{{ i18n.language() === 'ta' ? 'மீண்டும் முயற்சிக்கவும்' : 'Try again' }}</button></p>
        } @else if (categoryService.categories().length) {
          <div class="nc-pro-category-grid">
            @for (category of categoryService.categories().slice(0, 8); track category.id) {
              <a [routerLink]="['/services']" [queryParams]="{ category: category.id }" class="nc-pro-category-card">
                <div class="nc-pro-icon-wrapper" [class]="'tone-' + categoryTone(category)">
                  <i class="bi" [class]="'bi ' + (category.icon || categoryIcon(category))"></i>
                </div>
                <div class="nc-pro-category-content">
                  <h3>{{ i18n.language() === 'ta' ? category.nameTamil : category.nameEnglish }}</h3>
                  <p class="nc-pro-category-count">{{ category.subcategories.length > 0 ? category.subcategories.length + ' ' : '' }}{{ i18n.language() === 'ta' ? 'சேவைகள்' : 'services' }}</p>
                  <span class="nc-pro-arrow"><i class="bi bi-arrow-right"></i></span>
                </div>
              </a>
            }
          </div>
        } @else {
          <div class="nc-pro-category-grid">
            @for (item of categoryPlaceholders; track item.label) {
              <a class="nc-pro-category-card" routerLink="/services">
                <div class="nc-pro-icon-wrapper" [class]="item.tone">
                  <i class="bi" [class]="'bi ' + item.icon"></i>
                </div>
                <div class="nc-pro-category-content">
                  <h3>{{ i18n.language() === 'ta' ? item.ta : item.label }}</h3>
                  <p class="nc-pro-category-count">—</p>
                  <span class="nc-pro-arrow"><i class="bi bi-arrow-right"></i></span>
                </div>
              </a>
            }
          </div>
        }
      </section>

      <section class="nc-community" id="about" aria-labelledby="nc-community-title">
        <div class="nc-community-leaves" aria-hidden="true">✦</div>
        <div class="nc-community-copy">
          <p class="nc-kicker">{{ i18n.language() === 'ta' ? 'நம் சமூகம்' : 'OUR COMMUNITY' }}</p>
          <h2 id="nc-community-title">{{ i18n.language() === 'ta' ? 'மக்களால் இணையும் ஊர்' : 'A town connected by its people' }}</h2>
          <p>{{ i18n.language() === 'ta' ? 'உள்ளூர் சேவைகள், வணிகங்கள் மற்றும் நிகழ்வுகளை ஒரே இடத்தில் இணைத்து அன்றாட வாழ்க்கையை எளிதாக்குவதே நம் நோக்கம்.' : 'Nam Chidambaram brings together local services, businesses, events and useful information to make everyday life easier for our residents and for people connected to Chidambaram around the world.' }}</p>
          <a class="nc-orange-button" routerLink="/services">{{ i18n.language() === 'ta' ? 'மேலும் அறிய' : 'Learn more' }} <i class="bi bi-arrow-right"></i></a>
        </div>
        <div class="nc-community-art" aria-hidden="true">
          <div class="nc-round-art nc-round-art-large"><i class="bi bi-flower1"></i><span>சிதம்பரம்</span></div>
          <div class="nc-round-art nc-round-art-small"><i class="bi bi-building"></i></div>
          <span class="nc-art-orbit"></span>
        </div>
        <div class="nc-community-points">
          @for (item of communityValues; track item.id) {
            <div class="nc-community-point"><span class="nc-point-icon"><i class="bi" [class]="'bi ' + item.icon"></i></span><div><strong>{{ i18n.language() === 'ta' ? item.titleTamil : item.titleEnglish }}</strong><p>{{ i18n.language() === 'ta' ? item.descriptionTamil : item.descriptionEnglish }}</p></div></div>
          }
        </div>
      </section>

      <section class="nc-section nc-featured" id="featured-listings" aria-labelledby="nc-featured-title">
        <div class="nc-section-heading">
          <div><h2 id="nc-featured-title">{{ i18n.language() === 'ta' ? 'உள்ளூர் சிறப்பு சேவைகள்' : 'Featured Local Services' }}</h2><p>{{ i18n.language() === 'ta' ? 'உங்கள் தேவைக்கு ஏற்ற உள்ளூர் சேவைகளைப் பாருங்கள்.' : 'Handpicked services to help you get started.' }}</p></div>
          <a class="nc-view-link" routerLink="/services">{{ i18n.language() === 'ta' ? 'அனைத்து சேவைகளும்' : 'View all services' }} <i class="bi bi-arrow-right"></i></a>
        </div>
        @if (listingsLoading) {
          <p class="nc-state">{{ i18n.language() === 'ta' ? 'சேவைகள் ஏற்றப்படுகின்றன…' : 'Loading featured services…' }}</p>
        } @else if (featuredListings.length) {
          <div class="nc-listing-grid">
            @for (listing of featuredListings.slice(0, 6); track listing.id; let i = $index) {
              <a class="nc-listing-card" [routerLink]="['/providers', listing.service_providers.id]">
                <div class="nc-listing-image" [class]="'nc-listing-image tone-' + (i % 6)" aria-hidden="true"><i class="bi" [class]="listingIcon(i)"></i><span class="nc-image-glow"></span></div>
                <div class="nc-listing-content"><div class="nc-listing-title-row"><span class="nc-provider-name">{{ listing.service_providers.display_name }}</span><span class="nc-verified"><i class="bi bi-patch-check-fill"></i> {{ i18n.language() === 'ta' ? 'சரிபார்க்கப்பட்டது' : 'Verified' }}</span></div><h3>{{ listing.title }}</h3><p>{{ listing.description }}</p><span class="nc-listing-location"><i class="bi bi-geo-alt"></i> {{ listingLocation(listing) }}</span></div>
              </a>
            }
          </div>
        } @else {
          <p class="nc-state">{{ i18n.language() === 'ta' ? 'வெளியிடப்பட்ட சேவைகள் கிடைக்கும் போது இங்கே காண்பிக்கப்படும்.' : 'Published services will appear here when available.' }}</p>
        }
      </section>

      <section class="nc-advertising" aria-label="Business advertising">
        <div class="nc-ad-ornament" aria-hidden="true"><i class="bi bi-buildings"></i></div>
        <div class="nc-ad-copy"><p class="nc-kicker">{{ i18n.language() === 'ta' ? 'உள்ளூர் வணிகங்களுக்கு' : 'GROW YOUR BUSINESS' }}</p><h2>{{ i18n.language() === 'ta' ? 'நம் சிதம்பரத்தில் உங்கள் வணிகத்தை வளருங்கள்' : 'Grow Your Business in Nam Chidambaram' }}</h2><p>{{ i18n.language() === 'ta' ? 'உள்ளூர் மக்கள் மற்றும் உலகெங்கும் உள்ள சிதம்பரம் மக்களைச் சென்றடையுங்கள்.' : 'Reach local residents and the Chidambaram community around the world.' }}</p></div>
        <div class="nc-ad-options"><span><i class="bi bi-megaphone"></i> {{ i18n.language() === 'ta' ? 'விளம்பரங்கள்' : 'Banner Ads' }}</span><span><i class="bi bi-shop"></i> {{ i18n.language() === 'ta' ? 'சிறப்பு சேவைகள்' : 'Featured Listings' }}</span><span><i class="bi bi-calendar-event"></i> {{ i18n.language() === 'ta' ? 'நிகழ்வு விளம்பரம்' : 'Event Promotions' }}</span></div>
        <a routerLink="/services/submit" class="nc-orange-button">{{ i18n.language() === 'ta' ? 'விளம்பரம் செய்யுங்கள்' : 'Advertise With Us' }} <i class="bi bi-arrow-right"></i></a>
      </section>

      <section class="nc-section nc-events" id="nc-events" aria-labelledby="nc-events-title">
        <div class="nc-section-heading"><div><h2 id="nc-events-title">{{ i18n.language() === 'ta' ? 'வரவிருக்கும் நிகழ்வுகள்' : 'Upcoming Events' }}</h2><p>{{ i18n.language() === 'ta' ? 'சிதம்பரம் சமூக நிகழ்வுகளில் பங்கேற்கவும்.' : 'Be part of the vibrant Chidambaram community.' }}</p></div><a class="nc-view-link" routerLink="/services">{{ i18n.language() === 'ta' ? 'மேலும் பார்க்க' : 'View all events' }} <i class="bi bi-arrow-right"></i></a></div>
        <div class="nc-event-grid">
          @for (event of communityEvents; track event.title) {
            <article class="nc-event-card"><div class="nc-event-art" [class]="event.tone"><i class="bi" [class]="'bi ' + event.icon"></i></div><div class="nc-event-date"><strong>{{ event.day }}</strong><span>{{ event.month }}</span></div><div class="nc-event-copy"><h3>{{ i18n.language() === 'ta' ? event.titleTa : event.title }}</h3><p>{{ i18n.language() === 'ta' ? event.placeTa : event.place }}</p><a routerLink="/services">{{ i18n.language() === 'ta' ? 'விவரங்கள்' : 'View details' }} <i class="bi bi-arrow-right"></i></a></div></article>
          }
        </div>
      </section>

      <section class="nc-stats" aria-label="Community statistics">
        <div><i class="bi bi-people-fill"></i><span><strong>10,000+</strong><small>{{ i18n.language() === 'ta' ? 'சமூக உறுப்பினர்கள்' : 'Community Members' }}</small></span></div>
        <div><i class="bi bi-shop"></i><span><strong>500+</strong><small>{{ i18n.language() === 'ta' ? 'உள்ளூர் வணிகங்கள்' : 'Local Businesses' }}</small></span></div>
        <div><i class="bi bi-calendar-event"></i><span><strong>100+</strong><small>{{ i18n.language() === 'ta' ? 'ஆண்டு நிகழ்வுகள்' : 'Annual Events' }}</small></span></div>
        <div><i class="bi bi-heart"></i><span><strong>{{ i18n.language() === 'ta' ? 'வலுவான சமூகம்' : 'A Stronger' }}</strong><small>{{ i18n.language() === 'ta' ? 'சிதம்பரம்' : 'Chidambaram' }}</small></span></div>
      </section>
    </div>
  `,
  styleUrl: './home.component.scss',
})
export class LandingComponent implements OnInit, OnDestroy {
  protected readonly i18n = inject(LanguageService);
  protected readonly categoryService = inject(ServiceCategoryService);
  private readonly directory = inject(ServiceDirectoryService);
  private readonly cdr = inject(ChangeDetectorRef);
  private readonly router = inject(Router);
  protected readonly communityValues = LANDING_VALUES;
  protected readonly serviceHighlights = SERVICE_HIGHLIGHTS;

  protected readonly categoryPlaceholders = [
    { label: 'Home Services', ta: 'வீட்டுச் சேவைகள்', icon: 'bi-house-heart', tone: 'tone-green' },
    { label: 'Education', ta: 'கல்வி', icon: 'bi-mortarboard', tone: 'tone-purple' },
    { label: 'Healthcare', ta: 'மருத்துவம்', icon: 'bi-heart-pulse', tone: 'tone-rose' },
    { label: 'Construction', ta: 'கட்டுமானம்', icon: 'bi-houses', tone: 'tone-orange' },
    { label: 'Professional', ta: 'தொழில்முறை சேவைகள்', icon: 'bi-people', tone: 'tone-blue' },
    { label: 'Shops & Retail', ta: 'கடைகள்', icon: 'bi-shop', tone: 'tone-pink' },
    { label: 'Food & Dining', ta: 'உணவு', icon: 'bi-cup-hot', tone: 'tone-orange' },
    { label: 'Transport', ta: 'போக்குவரத்து', icon: 'bi-car-front', tone: 'tone-blue' },
    { label: 'Events', ta: 'நிகழ்வுகள்', icon: 'bi-calendar-event', tone: 'tone-purple' },
    { label: 'More Services', ta: 'மேலும் சேவைகள்', icon: 'bi-three-dots', tone: 'tone-green' },
  ] as const;
  protected readonly communityEvents = [
    { day: '05', month: 'OCT', title: 'Chidambaram Temple Festival', titleTa: 'சிதம்பரம் கோவில் திருவிழா', place: 'Chidambaram Nataraja Temple', placeTa: 'சிதம்பரம் நடராஜர் கோவில்', icon: 'bi-stars', tone: 'event-gold' },
    { day: '12', month: 'OCT', title: 'Community Food Distribution', titleTa: 'சமூக அன்னதானம்', place: 'East Car Street', placeTa: 'கிழக்கு ரத வீதி', icon: 'bi-people', tone: 'event-green' },
    { day: '20', month: 'OCT', title: 'Tree Plantation Drive', titleTa: 'மரக்கன்று நடும் நிகழ்வு', place: 'Chidambaram', placeTa: 'சிதம்பரம்', icon: 'bi-flower1', tone: 'event-leaf' },
    { day: '28', month: 'OCT', title: 'Local Business Meet', titleTa: 'உள்ளூர் வணிகர் சந்திப்பு', place: 'Community Hall', placeTa: 'சமூகக் கூடம்', icon: 'bi-shop', tone: 'event-blue' },
  ] as const;
  protected readonly heroSlides = [
    { id: 'town', image: 'assets/images/chidambaram-hero.png', alt: 'Chidambaram temple and local community', kickerEn: 'OUR TOWN · OUR PEOPLE', kickerTa: 'நம் ஊர் · நம் மக்கள்', titleEn: 'A closer connection to Chidambaram', titleTa: 'சிதம்பரத்துடன் இன்னும் நெருக்கமான இணைப்பு' },
    { id: 'community', image: 'assets/images/chidambaram-hero1.png', alt: 'Local services and community life in Chidambaram', kickerEn: 'LOCAL LIFE, MADE EASIER', kickerTa: 'உள்ளூர் வாழ்க்கை எளிதாக', titleEn: 'Discover the people behind local services', titleTa: 'உள்ளூர் சேவைகளின் பின்னால் உள்ள மக்களைக் கண்டறியுங்கள்' },
    { id: 'services', image: 'assets/images/chidambaram-hero.png', alt: 'Explore services across Chidambaram', kickerEn: 'FIND WHAT YOU NEED', kickerTa: 'உங்களுக்குத் தேவையானதைத் தேடுங்கள்', titleEn: 'Your local directory starts here', titleTa: 'உங்கள் உள்ளூர் சேவைத் தேடல் இங்கே தொடங்குகிறது' },
  ] as const;
  protected activeSlide = 0;
  protected featuredListings: ServiceListing[] = [];
  protected listingsLoading = false;
  private carouselTimer?: ReturnType<typeof setInterval>;
  private carouselPaused = false;
  private prefersReducedMotion = false;

  ngOnInit(): void {
    void this.loadCategories();
    void this.loadFeaturedListings();
    if (typeof window !== 'undefined') {
      this.prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
      this.startCarousel();
    }
  }

  ngOnDestroy(): void {
    this.stopCarousel();
  }

  protected async loadCategories(): Promise<void> {
    await this.categoryService.load();
  }

  protected async loadFeaturedListings(): Promise<void> {
    this.listingsLoading = true;
    try {
      const page = await this.directory.search(null, null, '', 0);
      this.featuredListings = page.listings.slice(0, 4);
    } catch {
      this.featuredListings = [];
    } finally {
      this.listingsLoading = false;
      this.cdr.markForCheck();
    }
  }

  protected listingIcon(index: number): string {
    return ['bi-house-gear', 'bi-building', 'bi-heart-pulse', 'bi-tools', 'bi-cup-hot', 'bi-flower1'][index % 6];
  }

  protected listingImage(listing: ServiceListing): string | null {
    const media = listing.listing_media
      .filter(item => item.media_assets?.visibility === 'public' && item.media_assets.media_type === 'image')
      .sort((a, b) => a.sort_order - b.sort_order)[0]?.media_assets;
    return media ? this.directory.imageUrl(media.storage_path) : null;
  }

  protected listingLocation(listing: ServiceListing): string {
    const place = listing.listing_locations.find(item => item.locations)?.locations;
    if (!place) return this.i18n.language() === 'ta' ? 'சிதம்பரம்' : 'Chidambaram';
    return this.i18n.language() === 'ta' ? place.name_ta : place.name_en ?? place.name_ta;
  }

  protected categoryIcon(category: any): string {
    const iconMap: { [key: string]: string } = {
      'home': 'bi-house-heart', 'housing': 'bi-house-heart', 'construction': 'bi-hammer',
      'health': 'bi-heart-pulse', 'medical': 'bi-heart-pulse', 'wellness': 'bi-heart-pulse',
      'education': 'bi-mortarboard', 'learning': 'bi-mortarboard', 'training': 'bi-mortarboard',
      'business': 'bi-briefcase', 'professional': 'bi-briefcase', 'services': 'bi-briefcase',
      'retail': 'bi-shop', 'shopping': 'bi-shop', 'stores': 'bi-shop',
      'food': 'bi-cup-hot', 'dining': 'bi-cup-hot', 'restaurant': 'bi-cup-hot',
      'transport': 'bi-car-front', 'travel': 'bi-car-front', 'logistics': 'bi-car-front',
      'entertainment': 'bi-ticket-perforated', 'events': 'bi-calendar-event', 'activities': 'bi-calendar-event',
    };
    const categoryName = (category.nameEnglish ?? category.nameTamil ?? '').toLowerCase();
    for (const [key, icon] of Object.entries(iconMap)) {
      if (categoryName.includes(key)) return icon;
    }
    return 'bi-grid-3x3-gap';
  }

  protected categoryTone(category: any): string {
    const toneMap: { [key: string]: string } = {
      'home': 'green', 'housing': 'green', 'construction': 'orange',
      'health': 'rose', 'medical': 'rose', 'wellness': 'rose',
      'education': 'purple', 'learning': 'purple', 'training': 'purple',
      'business': 'blue', 'professional': 'blue', 'services': 'blue',
      'retail': 'pink', 'shopping': 'pink', 'stores': 'pink',
      'food': 'orange', 'dining': 'orange', 'restaurant': 'orange',
      'transport': 'blue', 'travel': 'blue', 'logistics': 'blue',
      'entertainment': 'gold', 'events': 'purple', 'activities': 'purple',
    };
    const categoryName = (category.nameEnglish ?? category.nameTamil ?? '').toLowerCase();
    for (const [key, tone] of Object.entries(toneMap)) {
      if (categoryName.includes(key)) return tone;
    }
    const tones = ['green', 'blue', 'rose', 'orange', 'purple', 'pink', 'gold'];
    return tones[Math.abs(category.id?.charCodeAt(0) ?? 0) % tones.length];
  }

  protected selectSlide(index: number): void {
    this.activeSlide = index;
    this.restartCarousel();
  }
  protected nextSlide(): void { this.activeSlide = (this.activeSlide + 1) % this.heroSlides.length; }
  protected previousSlide(): void { this.activeSlide = (this.activeSlide - 1 + this.heroSlides.length) % this.heroSlides.length; }
  protected pauseCarousel(): void { this.carouselPaused = true; this.stopCarousel(); }
  protected resumeCarousel(): void { this.carouselPaused = false; this.startCarousel(); }
  private restartCarousel(): void { this.stopCarousel(); this.startCarousel(); }
  private startCarousel(): void {
    if (this.prefersReducedMotion || this.carouselPaused || this.carouselTimer || this.heroSlides.length < 2) return;
    this.carouselTimer = setInterval(() => this.nextSlide(), 6000);
  }
  private stopCarousel(): void {
    if (this.carouselTimer) clearInterval(this.carouselTimer);
    this.carouselTimer = undefined;
  }

  protected search(event: Event, term: string): void {
    event.preventDefault();
    void this.router.navigate([term.trim() ? '/service-search' : '/services'], { queryParams: term.trim() ? { q: term.trim() } : {} });
  }
}
