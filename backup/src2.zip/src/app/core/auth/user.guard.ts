import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';
import { AuthService } from './auth.service';

export const userGuard: CanActivateFn = async (_route, state) => {
  const auth = inject(AuthService);
  const router = inject(Router);
  await auth.ready();
  if (auth.isAuthenticated()) return true;
  return router.createUrlTree(['/auth/sign-in'], { queryParams: { returnUrl: state.url } });
};
